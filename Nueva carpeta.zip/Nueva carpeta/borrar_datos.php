<?php
$host = "localhost"; $username = "root"; $password = ""; $dbname = "vitalis";
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    // Borramos los contactos primero por la llave foránea
    $pdo->exec("DELETE FROM contactos_emergencia");
    // Luego borramos al usuario
    $pdo->exec("DELETE FROM usuarios");
    echo "ok";
} catch (Exception $e) {
    echo "error";
}
?>