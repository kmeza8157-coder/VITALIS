const CACHE_NAME = 'vitalis-v1';
const ASSETS_TO_CACHE = [
  'index.php',
  'manifest.json',
  'icons/icon-192.png'
  // Agrega aquí tus otros archivos CSS o JS si los tienes en archivos separados
];

// Instalación
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS_TO_CACHE))
  );
});

// Estrategia: Network First para index.php (esto evita problemas con la Base de Datos)
self.addEventListener('fetch', (event) => {
  if (event.request.url.includes('index.php')) {
    event.respondWith(
      fetch(event.request).catch(() => caches.match('index.php'))
    );
  } else {
    event.respondWith(
      caches.match(event.request).then((response) => response || fetch(event.request))
    );
  }
});