<?php
include 'conexion.php';

$stmt = $pdo->query("SELECT * FROM usuarios LIMIT 1");
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if ($usuario) {
    // Obtener contactos asociados
    $stmtC = $pdo->prepare("SELECT nombre, telefono FROM contactos_emergencia WHERE usuario_id = ?");
    $stmtC->execute([$usuario['id']]);
    $usuario['contacts'] = $stmtC->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($usuario); // Aquí está la magia: la app recibe un objeto legible
} else {
    echo json_encode(["error" => "No encontrado"]);
}
?>