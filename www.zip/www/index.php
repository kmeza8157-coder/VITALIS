<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host     = "localhost";
$username = "root";
$password = ""; 
$dbname   = "vitalis";

// --- 1. LÓGICA DE RESETEO INTEGRADA ---
// Si la URL recibe ?reset=true, limpiamos la base de datos y recargamos
if (isset($_GET['reset']) && $_GET['reset'] == 'true') {
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // TRUNCATE limpia completamente las tablas y reinicia los IDs
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");
        $pdo->exec("TRUNCATE TABLE contactos_emergencia;");
        $pdo->exec("TRUNCATE TABLE usuarios;");
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");
        
        header("Location: index.php");
        exit();
    } catch (Exception $e) {
        die("Error al resetear la base de datos: " . $e->getMessage());
    }
}

// --- 2. LÓGICA DE GUARDADO (POST) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['guardar_registro'])) {
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->beginTransaction();

        // 1. Guardar Usuario
        $sql = "INSERT INTO usuarios (nombre_completo, tipo_sangre, condiciones_medicas, alergias) 
                VALUES (:nombre, :sangre, :condiciones, :alergias)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':nombre'      => $_POST['nombre_completo'],
            ':sangre'      => $_POST['tipo_sangre'],
            ':condiciones' => $_POST['condiciones_medicas'],
            ':alergias'    => $_POST['alergias']
        ]);
        $usuario_id = $pdo->lastInsertId();

        // 2. Guardar Contactos (Si existen)
        if (!empty($_POST['contactos_nombre'])) {
            $stmtC = $pdo->prepare("INSERT INTO contactos_emergencia (usuario_id, nombre, telefono) VALUES (?, ?, ?)");
            foreach ($_POST['contactos_nombre'] as $index => $nombre) {
                $telefono = $_POST['contactos_telefono'][$index];
                if (!empty($nombre) && !empty($telefono)) {
                    $stmtC->execute([$usuario_id, $nombre, $telefono]);
                }
            }
        }

        $pdo->commit();
        // Añadimos '?status=success' para que el JS sepa qué hacer
        header("Location: index.php?status=success");
        exit();
    } catch (Exception $e) {
        if (isset($pdo)) $pdo->rollBack();
        $mensaje_debug = "Error al guardar: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>VITALIS — Primeros Auxilios</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="manifest" href="manifest.json">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="#0B1F3A">
<meta name="apple-mobile-web-app-title" content="VITALIS">
<link rel="apple-touch-icon" href="icons/icon-192.png">

<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --navy:    #0B1F3A;
    --navy-2:  #102847;
    --navy-3:  #183560;
    --crimson: #D9232D;
    --crimson-soft: #FF3B47;
    --teal:    #1AAFA0;
    --teal-soft: #22CDB8;
    --amber:   #F5A623;
    --white:   #F7F9FB;
    --gray-1:  #C8D2DF;
    --gray-2:  #8495AB;
    --success: #22A86B;
    --font-display: 'Space Grotesk', sans-serif;
    --font-body:    'Inter', sans-serif;
  }

  html, body {
    background: var(--navy);
    color: var(--white);
    font-family: var(--font-body);
    min-height: 100vh;
  }

  /* ── LAYOUT ── */
  .app-shell {
    max-width: 420px;
    margin: 0 auto;
    min-height: 100vh;
    background: var(--navy);
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
  }

  /* ── STATUS BAR ── */
  .status-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 20px 0;
    font-size: 12px;
    color: var(--gray-1);
    font-family: var(--font-display);
    z-index: 100;
  }
  .status-bar .time { font-weight: 700; font-size: 14px; color: var(--white); }
  .status-icons { display: flex; gap: 6px; align-items: center; }

  /* ── FORMULARIO BIENVENIDA / REGISTRO ── */
  #screen-welcome {
    padding: 20px;
    justify-content: flex-start;
  }
  .welcome-header {
    text-align: center;
    margin-bottom: 20px;
    margin-top: 10px;
  }
  .welcome-title {
    font-family: var(--font-display);
    font-weight: 800;
    font-size: 28px;
    color: var(--white);
  }
  .welcome-title span { color: var(--teal); }
  .welcome-sub {
    font-size: 13px;
    color: var(--gray-2);
    margin-top: 6px;
    line-height: 1.4;
  }
  .form-group {
    margin-bottom: 14px;
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  .form-group label {
    font-family: var(--font-display);
    font-size: 12px;
    font-weight: 700;
    letter-spacing: .5px;
    color: var(--gray-1);
    text-transform: uppercase;
  }
  .form-group input, .form-group select {
    background: var(--navy-2);
    border: 1.5px solid var(--navy-3);
    border-radius: 12px;
    padding: 12px 14px;
    color: var(--white);
    font-family: var(--font-body);
    font-size: 14px;
    outline: none;
    transition: border-color .2s;
  }
  .form-group input:focus, .form-group select:focus {
    border-color: var(--teal);
  }
  .form-group input::placeholder { color: var(--gray-2); }
  .form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
  }

  /* SUB-SECCIÓN DINÁMICA DE CONTACTOS */
  .dynamic-contacts-box {
    background: rgba(24, 53, 96, 0.3);
    border: 1px dashed var(--navy-3);
    border-radius: 14px;
    padding: 12px;
    margin-top: 5px;
  }
  .added-contact-pill {
    background: var(--navy-2);
    border: 1px solid var(--navy-3);
    padding: 8px 12px;
    border-radius: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 13px;
    margin-bottom: 8px;
  }
  .added-contact-pill span { color: var(--gray-1); }
  .remove-contact-btn {
    background: none;
    border: none;
    color: var(--crimson-soft);
    font-weight: bold;
    cursor: pointer;
    font-size: 14px;
    padding: 0 4px;
  }
  .btn-secondary {
    background: none;
    border: 1.5px solid var(--teal);
    color: var(--teal-soft);
    padding: 10px;
    border-radius: 10px;
    font-family: var(--font-display);
    font-weight: 600;
    font-size: 13px;
    cursor: pointer;
    width: 100%;
    transition: all 0.2s;
  }
  .btn-secondary:hover {
    background: rgba(26, 175, 160, 0.1);
  }

  /* ── TOP NAV ── */
  .top-nav {
    padding: 16px 20px 0;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
  }
  .logo {
    font-family: var(--font-display);
    font-weight: 800;
    font-size: 26px;
    color: var(--white);
    letter-spacing: -0.5px;
    line-height: 1;
  }
  .logo span { color: var(--teal); }
  .logo-sub {
    font-size: 10px;
    font-weight: 500;
    color: var(--gray-2);
    letter-spacing: 1.5px;
    text-transform: uppercase;
    margin-top: 2px;
  }
  .profile-btn {
    width: 40px; height: 40px;
    border-radius: 50%;
    background: var(--navy-3);
    border: 2px solid var(--teal);
    display: flex; align-items: center; justify-content: center;
    cursor: pointer;
    font-size: 18px;
  }

  /* ── SEARCH ── */
  .search-wrap { padding: 18px 20px 0; }
  .search-box {
    background: var(--navy-2);
    border: 1.5px solid var(--navy-3);
    border-radius: 14px;
    display: flex;
    align-items: center;
    padding: 12px 16px;
    gap: 10px;
    transition: border-color .2s;
  }
  .search-box:focus-within { border-color: var(--teal); }
  .search-box input {
    background: none;
    border: none;
    outline: none;
    color: var(--white);
    font-family: var(--font-body);
    font-size: 15px;
    flex: 1;
  }
  .search-box input::placeholder { color: var(--gray-2); }
  .search-icon { color: var(--gray-2); font-size: 16px; }

  /* ── SOS BUTTON ── */
  .sos-section {
    padding: 24px 20px 0;
    display: flex;
    justify-content: center;
  }
  .sos-outer {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  @keyframes pulse-ring {
    0%   { transform: scale(1);   opacity: .5; }
    70%  { transform: scale(1.35); opacity: 0; }
    100% { transform: scale(1.35); opacity: 0; }
  }
  @keyframes pulse-ring2 {
    0%   { transform: scale(1);   opacity: .3; }
    70%  { transform: scale(1.55); opacity: 0; }
    100% { transform: scale(1.55); opacity: 0; }
  }
  .pulse-ring {
    position: absolute;
    width: 120px; height: 120px;
    border-radius: 50%;
    background: var(--crimson);
    animation: pulse-ring 2s cubic-bezier(.455,.03,.515,.955) infinite;
  }
  .pulse-ring2 {
    position: absolute;
    width: 120px; height: 120px;
    border-radius: 50%;
    background: var(--crimson);
    animation: pulse-ring2 2s cubic-bezier(.455,.03,.515,.955) .4s infinite;
  }
  .sos-btn {
    position: relative;
    width: 120px; height: 120px;
    border-radius: 50%;
    background: linear-gradient(145deg, var(--crimson-soft), var(--crimson));
    border: none;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    box-shadow: 0 0 40px rgba(217,35,45,.5), 0 8px 24px rgba(0,0,0,.4);
    transition: transform .1s;
    z-index: 2;
  }
  .sos-btn:active { transform: scale(.96); }
  .sos-icon { font-size: 32px; line-height: 1; }
  .sos-label {
    font-family: var(--font-display);
    font-weight: 800;
    font-size: 16px;
    letter-spacing: 2px;
    color: #fff;
    margin-top: 2px;
  }
  .sos-caption {
    text-align: center;
    font-size: 11px;
    color: var(--gray-2);
    margin-top: 10px;
    font-weight: 500;
    letter-spacing: .3px;
  }

  /* ── SECTION HEADER ── */
  .section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 28px 20px 12px;
  }
  .section-title {
    font-family: var(--font-display);
    font-weight: 700;
    font-size: 18px;
    color: var(--white);
  }

  /* ── CATEGORY PILLS ── */
  .pills {
    display: flex;
    gap: 8px;
    padding: 0 20px;
    overflow-x: auto;
    scrollbar-width: none;
  }
  .pills::-webkit-scrollbar { display: none; }
  .pill {
    flex-shrink: 0;
    padding: 7px 16px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    border: 1.5px solid transparent;
    transition: all .15s;
    font-family: var(--font-display);
  }
  .pill.active { background: var(--teal); color: var(--navy); border-color: var(--teal); }
  .pill.inactive { background: var(--navy-2); color: var(--gray-1); border-color: var(--navy-3); }
  .pill:hover:not(.active) { border-color: var(--teal); color: var(--teal); }

  /* ── EMERGENCY CARDS ── */
  .cards-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    padding: 16px 20px;
  }
  .card {
    background: var(--navy-2);
    border-radius: 18px;
    padding: 18px 14px 16px;
    cursor: pointer;
    border: 1.5px solid var(--navy-3);
    transition: all .18s;
    position: relative;
    overflow: hidden;
  }
  .card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
    border-radius: 18px 18px 0 0;
  }
  .card.red::before    { background: var(--crimson); }
  .card.teal::before  { background: var(--teal); }
  .card.amber::before { background: var(--amber); }
  .card.blue::before  { background: #4A90D9; }
  
  .card:hover, .card:focus-within {
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(0,0,0,.3);
  }

  .card-icon {
    font-size: 30px;
    display: block;
    margin-bottom: 10px;
    line-height: 1;
  }
  .card-title {
    font-family: var(--font-display);
    font-weight: 700;
    font-size: 14px;
    color: var(--white);
    line-height: 1.2;
    margin-bottom: 4px;
  }
  .card-steps {
    font-size: 11px;
    color: var(--gray-2);
    font-weight: 500;
  }

  /* ── BOTTOM NAV ── */
  .bottom-nav {
    margin-top: auto;
    padding: 0 20px 28px;
    display: flex;
    justify-content: space-around;
    background: linear-gradient(to top, var(--navy) 80%, transparent);
    padding-top: 20px;
    z-index: 10;
  }
  .nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    cursor: pointer;
    padding: 8px 16px;
    border-radius: 12px;
    transition: background .15s;
  }
  .nav-item.active { background: rgba(26,175,160,.12); }
  .nav-label {
    font-size: 10px;
    font-weight: 600;
    letter-spacing: .3px;
    font-family: var(--font-display);
    color: var(--gray-2);
  }
  .nav-item.active .nav-label { color: var(--teal); }

  /* ── SCREENS CONTROL ── */
  .screen {
    display: none;
    flex-direction: column;
    flex: 1;
    animation: fadeIn .2s ease;
  }
  .screen.active { display: flex; }
  @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }

  #screen-home, #screen-profile, #screen-learn, #screen-map, #screen-welcome { flex: 1; overflow-y: auto; padding-bottom: 100px; }

  /* ── GUIDE SCREEN ── */
  #screen-guide { flex: 1; background: var(--navy); overflow-y: auto; padding-bottom: 40px; }
  .guide-header {
    padding: 16px 20px;
    display: flex;
    align-items: center;
    gap: 14px;
    border-bottom: 1px solid var(--navy-3);
  }
  .back-btn {
    width: 38px; height: 38px;
    background: var(--navy-2);
    border: 1.5px solid var(--navy-3);
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer;
    font-size: 18px;
    flex-shrink: 0;
  }
  .guide-title {
    font-family: var(--font-display);
    font-weight: 700;
    font-size: 19px;
    color: var(--white);
  }
  .guide-sub { font-size: 12px; color: var(--gray-2); margin-top: 1px; }

  .step-progress { padding: 16px 20px 0; }
  .step-track { display: flex; gap: 6px; margin-bottom: 8px; }
  .step-dot {
    flex: 1; height: 4px; border-radius: 4px;
    background: var(--navy-3); transition: background .3s;
  }
  .step-dot.done   { background: var(--teal); }
  .step-dot.active { background: var(--crimson); }
  .step-info {
    display: flex; justify-content: space-between;
    font-size: 12px; color: var(--gray-2); font-weight: 500;
  }

  .step-card {
    margin: 20px; background: var(--navy-2);
    border-radius: 22px; padding: 24px;
    border: 1.5px solid var(--navy-3);
  }
  .step-number {
    font-family: var(--font-display); font-size: 11px; font-weight: 700;
    color: var(--crimson); letter-spacing: 1.5px; text-transform: uppercase; margin-bottom: 8px;
  }
  .step-heading {
    font-family: var(--font-display); font-weight: 800; font-size: 22px;
    color: var(--white); line-height: 1.2; margin-bottom: 14px;
  }
  .step-body { font-size: 15px; color: var(--gray-1); line-height: 1.6; margin-bottom: 20px; }
  .step-tip {
    background: rgba(26,175,160,.1); border-left: 3px solid var(--teal);
    border-radius: 0 10px 10px 0; padding: 12px 14px;
    font-size: 13px; color: var(--teal-soft); line-height: 1.5; margin-bottom: 20px;
  }

  .step-actions { padding: 0 20px 10px; display: flex; gap: 12px; }
  .btn-voice {
    width: 52px; height: 52px; border-radius: 14px;
    background: var(--navy-2); border: 1.5px solid var(--navy-3);
    font-size: 22px; display: flex; align-items: center; justify-content: center;
    cursor: pointer; flex-shrink: 0;
  }
  .btn-next {
    flex: 1; height: 52px; border-radius: 14px;
    background: linear-gradient(135deg, var(--teal), var(--teal-soft));
    border: none; color: var(--navy); font-family: var(--font-display);
    font-weight: 700; font-size: 16px; cursor: pointer;
    display: flex; align-items: center; justify-content: center; gap: 8px;
    box-shadow: 0 4px 20px rgba(26,175,160,.35);
  }

  /* MAP SCREEN */
  .map-header { padding: 20px 20px 16px; font-family: var(--font-display); font-weight: 700; font-size: 20px; }
  .map-placeholder {
    margin: 0 20px; border-radius: 18px; height: 180px; background: var(--navy-2);
    border: 1.5px solid var(--navy-3); display: flex; align-items: center;
    justify-content: center; flex-direction: column; gap: 8px; color: var(--gray-2); font-size: 14px;
  }
  .map-emoji { font-size: 40px; }

  /* LEARN SCREEN */
  .learn-card { margin: 0 20px 12px; background: var(--navy-2); border-radius: 18px; overflow: hidden; border: 1.5px solid var(--navy-3); }
  .learn-thumb { height: 80px; display: flex; align-items: center; justify-content: center; font-size: 36px; position: relative; }
  .learn-thumb.red   { background: linear-gradient(135deg, rgba(217,35,45,.3), rgba(217,35,45,.1)); }
  .play-badge { position: absolute; top: 10px; right: 10px; background: rgba(0,0,0,.5); border-radius: 20px; padding: 3px 10px; font-size: 10px; color: #fff; font-weight: 600; }
  .learn-info { padding: 14px 16px; }
  .learn-title { font-family: var(--font-display); font-weight: 700; font-size: 15px; margin-bottom: 4px; }
  .learn-meta { display: flex; gap: 12px; font-size: 12px; color: var(--gray-2); }

  /* PROFILE SCREEN */
  .profile-hero { padding: 24px 20px 20px; text-align: center; border-bottom: 1px solid var(--navy-3); }
  .avatar { width: 72px; height: 72px; border-radius: 50%; background: var(--navy-3); border: 3px solid var(--teal); margin: 0 auto 12px; font-size: 32px; display: flex; align-items: center; justify-content: center; }
  .profile-name { font-family: var(--font-display); font-weight: 700; font-size: 20px; }
  .profile-sub { font-size: 13px; color: var(--gray-2); margin-top: 3px; }
  .blood-badge { display: inline-block; background: rgba(217,35,45,.15); color: var(--crimson-soft); font-family: var(--font-display); font-weight: 700; font-size: 13px; padding: 5px 14px; border-radius: 20px; margin-top: 10px; border: 1px solid rgba(217,35,45,.3); }
  .med-section { padding: 20px 20px 0; }
  .med-label { font-size: 11px; font-weight: 700; letter-spacing: 1px; color: var(--gray-2); text-transform: uppercase; margin-bottom: 10px; }
  .med-tags { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 20px; }
  .med-tag { font-size: 12px; font-weight: 600; padding: 6px 12px; border-radius: 8px; background: var(--navy-2); border: 1.5px solid var(--navy-3); color: var(--gray-1); }
  
  /* LISTA DE CONTACTOS EN EL PERFIL */
  .contacts-container-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-bottom: 20px;
  }
  .contact-card { background: var(--navy-2); border-radius: 14px; padding: 14px 16px; border: 1.5px solid var(--navy-3); display: flex; align-items: center; gap: 12px; }
  .contact-avatar { width: 40px; height: 40px; border-radius: 50%; background: var(--navy-3); display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0; }
  .contact-name { font-weight: 600; font-size: 14px; color: var(--white); }
  .contact-rel { font-size: 12px; color: var(--gray-2); margin-top: 2px; }
  .contact-call { margin-left: auto; width: 36px; height: 36px; border-radius: 50%; background: rgba(26,175,160,.15); border: none; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 16px; color: var(--teal-soft); }

  .offline-chip { display: flex; align-items: center; gap: 6px; background: rgba(26,175,160,.08); border: 1px solid rgba(26,175,160,.2); border-radius: 8px; padding: 8px 12px; margin: 12px 20px 0; font-size: 12px; color: var(--teal-soft); font-weight: 500; }
  .offline-dot { width: 7px; height: 7px; border-radius: 50%; background: var(--teal); }

  @media (min-width: 500px) {
    .app-shell { border-radius: 40px; margin: 30px auto; min-height: calc(100vh - 60px); box-shadow: 0 40px 100px rgba(0,0,0,.7), 0 0 0 10px rgba(255,255,255,.04); }
    body { background: #060D18; }
  }
</style>
</head>
<body>

<div class="app-shell">
  
  <div class="status-bar">
    <span class="time" id="device-time">00:00</span>
    <div class="status-icons">
      <span>●●●</span>
      <span>WiFi</span>
      <span>🔋</span>
    </div>
  </div>

  <div id="screen-welcome" class="screen">
    <div class="welcome-header">
      <div class="welcome-title">VITA<span>LIS</span></div>
      <div class="welcome-sub">Configura tu perfil médico de emergencia. Esta información se guardará en tu dispositivo móvil.</div>
    </div>

    <form action="index.php" method="POST" style="flex: 1; display:flex; flex-direction:column; gap: 4px;">
      <div class="form-group">
        <label>Nombre Completo</label>
        <input type="text" id="reg-name" name="nombre_completo" placeholder="Ej. Meza Bustillos Katherine" required>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>Tipo de Sangre</label>
          <select id="reg-blood" name="tipo_sangre">
            <option value="O+">O+</option>
            <option value="O-">O-</option>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
          </select>
        </div>
        <div class="form-group">
          <label>Conditions Médicas</label>
          <input type="text" id="reg-conditions" name="condiciones_medicas" placeholder="Ej. Asma (o 'Ninguna')">
        </div>
      </div>

      <div class="form-group">
        <label>Alergias Crónicas</label>
        <input type="text" id="reg-allergies" name="alergias" placeholder="Ej. Penicilina (o 'Ninguna')">
      </div>

      <div style="border-top: 1px solid var(--navy-3); margin: 8px 0; padding-top: 8px;"></div>

      <div class="form-group">
        <label>Contactos de Emergencia</label>
        <div id="contacts-inputs-container">
        </div>
        <input type="text" id="temp-cname" placeholder="Nombre (ej. Mamá)">
        <input type="tel" id="temp-cphone" placeholder="Teléfono">
        <button type="button" class="btn-secondary" onclick="addContactToForm()">+ Añadir Persona</button>
      </div>

      <button type="submit" name="guardar_registro" class="btn-next" style="margin-top: 10px; width: 100%;" 
              onclick="return saveInitialRegistration()">
        Guardar Perfil y Empezar ✓
      </button>
    </form>
  </div>

  <div id="screen-home" class="screen">
    <div class="top-nav">
      <div>
        <div class="logo">VITA<span>LIS</span></div>
        <div class="logo-sub">Primeros Auxilios</div>
      </div>
      <div class="profile-btn" onclick="showScreen('profile')">👤</div>
    </div>

    <div class="offline-chip">
      <div class="offline-dot"></div>
      Protocolos locales activos (SQLite)
    </div>

    <div class="search-wrap">
      <div class="search-box">
        <span class="search-icon">🔍</span>
        <input type="text" id="search-input" placeholder="Buscar emergencia…" oninput="filterEmergencies()">
      </div>
    </div>

    <div class="sos-section">
      <div>
        <div class="sos-outer">
          <div class="pulse-ring2"></div>
          <div class="pulse-ring"></div>
          <button class="sos-btn" id="sos-btn-trigger">
            <span class="sos-icon">🆘</span>
            <span class="sos-label">SOS</span>
          </button>
        </div>
        <p class="sos-caption">Presiona para activar · Alerta GPS a contactos</p>
      </div>
    </div>

    <div class="section-header">
      <span class="section-title">Categorías</span>
    </div>

    <div class="pills" id="category-pills-container">
      <div class="pill active" onclick="filterCategory('Todas', this)">Todas</div>
      <div class="pill inactive" onclick="filterCategory('Críticas', this)">Críticas</div>
      <div class="pill inactive" onclick="filterCategory('Respiración', this)">Respiración</div>
      <div class="pill inactive" onclick="filterCategory('Traumas', this)">Traumas</div>
    </div>

    <div class="cards-grid" id="emergencies-grid"></div>
  </div>

  <div id="screen-guide" class="screen">
    <div class="guide-header">
      <div class="back-btn" onclick="showScreen('home')">←</div>
      <div>
        <div class="guide-title" id="guide-main-title">Cargando...</div>
        <div class="guide-sub" id="guide-sub-title">Guía paso a paso</div>
      </div>
    </div>

    <div class="step-progress">
      <div class="step-track" id="step-dots-container"></div>
      <div class="step-info">
        <span id="step-counter-text">Paso 1 de 1</span>
        <span style="color:var(--crimson); font-weight:600;">● En curso</span>
      </div>
    </div>

    <div class="step-card">
      <div class="step-number" id="step-card-number">Paso 1</div>
      <div class="step-heading" id="step-card-heading">Cargando...</div>
      <div class="step-body" id="step-card-body">Por favor espera.</div>
      <div class="step-tip" id="step-card-tip">Cargando consejo...</div>
    </div>

    <div class="step-actions">
      <button class="btn-voice" id="btn-audio-speak" title="Leer en voz alta">🔊</button>
      <button class="btn-next" id="btn-next-step" onclick="nextStep()">Siguiente paso →</button>
    </div>
  </div>

  <div id="screen-map" class="screen">
    <div class="map-header">Centros de Atención</div>
    <div class="map-placeholder">
      <div class="map-emoji">🗺️</div>
      <div>Mapa de hospitales y farmacias</div>
    </div>
  </div>

  <div id="screen-learn" class="screen">
    <div class="section-header">
      <span class="section-title">Aprende antes de necesitarlo</span>
    </div>
    <div class="learn-card">
      <div class="learn-thumb red">❤️<span class="play-badge">▶ 4:30</span></div>
      <div class="learn-info">
        <div class="learn-title">RCP para adultos — Guía completa</div>
        <div class="learn-meta"><span>🎓 Certificado OMS</span></div>
      </div>
    </div>
  </div>

  <div id="screen-profile" class="screen">
    <div class="profile-hero">
      <div class="avatar">🙍</div>
      <div class="profile-name" id="prof-display-name">Katherine</div>
      <div class="profile-sub">Perfil médico de emergencia</div>
      <div class="blood-badge" id="prof-display-blood">🩸 Tipo O+</div>
    </div>

    <div class="med-section">
      <div class="med-label">Condiciones médicas</div>
      <div class="med-tags" id="prof-display-conditions"><span class="med-tag">Ninguna</span></div>
      
      <div class="med-label">Alergias crónicas</div>
      <div class="med-tags" id="prof-display-allergies"><span class="med-tag">Ninguna</span></div>
      
      <div class="med-label">Contactos de emergencia asignados</div>
      
      <div class="contacts-container-list" id="prof-display-contacts-list"></div>

      <!-- BOTÓN REINICIAR (AQUÍ ESTÁ BIEN UBICADO) -->
      <button onclick="reiniciarApp()" style="width: 100%; margin-top: 20px; background: none; border: 1px dashed var(--navy-3); color: var(--gray-2); padding: 8px; font-size:11px; border-radius:8px; cursor:pointer;">
        Reiniciar Aplicación (Borrar Todo)
      </button>
    </div> 
  </div> 

  <div class="bottom-nav" id="main-bottom-nav" style="display: none;">
    <div class="nav-item active" id="nav-home" onclick="showScreen('home')">
      <span>🏠</span><span class="nav-label">Inicio</span>
    </div>
    <div class="nav-item" id="nav-map" onclick="showScreen('map')">
      <span>📍</span><span class="nav-label">Mapa</span>
    </div>
    <div class="nav-item" id="nav-learn" onclick="showScreen('learn')">
      <span>📚</span><span class="nav-label">Aprender</span>
    </div>
    <div class="nav-item" id="nav-profile" onclick="showScreen('profile')">
      <span>👤</span><span class="nav-label">Perfil</span>
    </div>
  </div>

</div>

<script>
  // ── 1. DATOS DE PROTOCOLOS COMPLETOS ──
const DB_PROTOCOLS = [
    {
      id: "paro",
      title: "Paro Cardíaco",
      icon: "❤️",
      category: "Críticas",
      badge: "Crítico",
      badgeClass: "badge-critical",
      colorClass: "red",
      subTitle: "RCP · Maniobra de reanimación",
      steps: [
        { heading: "Verificar respuesta del paciente", body: "Sacude suavemente sus hombros y pregunta en voz alta: ¿Se encuentra bien? Si no responde, pasa al siguiente paso.", tip: "Mantén la calma y actúa con firmeza.", timer: false },
        { heading: "Llamar a emergencias", body: "Pide ayuda en voz alta. Si estás solo, llama al 911 de inmediato usando altavoz.", tip: "Especifica que estás ante un posible paro cardíaco.", timer: false },
        { heading: "Verificar respiración", body: "Observa si el pecho se eleva. No demores más de 10 segundos en confirmar si respira con normalidad.", tip: "Si boquea o no respira, asume un paro cardíaco.", timer: false },
        { heading: "Inicia las compresiones torácicas", body: "Coloca el talón de una mano en el centro del pecho. Entrelaza tus manos y comprime fuerte y rápido con los brazos completamente rectos.", tip: "Sigue el ritmo del cronómetro integrado (100-120 bpm).", timer: true },
        { heading: "Abrir vía aérea", body: "Inclina la cabeza del paciente hacia atrás levantando el mentón para abrir el paso del aire.", tip: "Esto prepara el terreno por si se dispone de una mascarilla de reanimación.", timer: false },
        { heading: "Ventilaciones de rescate (opcional)", body: "Si cuentas con entrenamiento, da 2 insuflaciones boca a boca tapando la nariz tras cada 30 compresiones.", tip: "Si no tienes entrenamiento, continúa solo con compresiones ininterrumpidas.", timer: false },
        { heading: "Mantener ciclo y buscar DEA", body: "No te detengas hasta que llegue la ayuda médica o tengas un Desfibrilador Externo Automático (DEA) a la mano.", tip: "Intercambia roles si hay alguien más para evitar la fatiga extrema.", timer: true }
      ]
    },
    {
      id: "asfixia",
      title: "Asfixia / Atragantamiento",
      icon: "🫁",
      category: "Respiración",
      badge: "Offline",
      badgeClass: "badge-offline",
      colorClass: "red",
      subTitle: "Maniobra de Heimlich",
      steps: [
        { heading: "Evaluar la tos del paciente", body: "Si el paciente está latiendo o tosiendo con fuerza, anímalo a seguir tosiendo de forma autónoma. No golpees su espalda.", tip: "Intervén únicamente si deja de emitir sonidos por completo.", timer: false },
        { heading: "Preguntar si se ahoga", body: "Confirma visualmente si lleva las manos al cuello (signo universal). Pregúntale firmemente: ¿Te estás ahogando? ¿Puedo ayudarte?", tip: "Si asiente sin poder hablar, inicia la acción.", timer: false },
        { heading: "Colocarse en posición", body: "Ponte de pie detrás de la persona y ubica una de tus piernas entre las suyas para tener estabilidad en caso de desmayo.", tip: "Inclina levemente al paciente hacia adelante.", timer: false },
        { heading: "Realizar compresiones abdominales", body: "Haz un puño con una mano justo arriba del ombligo, rodéalo con la otra mano y presiona con fuerza hacia adentro y hacia arriba en forma de 'J'.", tip: "Repite el movimiento firmemente hasta expulsar el objeto obstaculizador.", timer: false },
        { heading: "Monitorear pérdida de conocimiento", body: "Si la persona pierde el conocimiento, colócala suavemente en el suelo boca arriba e inicia maniobras de RCP.", tip: "Busca el objeto en la boca solo si es visible.", timer: false }
      ]
    },
    {
      id: "hemorragia",
      title: "Hemorragia Severa",
      icon: "🩸",
      category: "Traumas",
      badge: "Offline",
      badgeClass: "badge-offline",
      colorClass: "teal",
      subTitle: "Control de sangrado masivo",
      steps: [
        { heading: "Presión directa e inmediata", body: "Coloca un paño limpio o gasa directamente sobre la herida abierta y ejerce una presión manual firme y constante sin retirar la tela.", tip: "Si la sangre empapa el paño, no lo quites; añade otro encima.", timer: false },
        { heading: "Aplicación de vendaje compresivo", body: "Envuelve firmemente la zona afectada con una venda manteniendo la presión aplicada sobre la herida original.", tip: "Monitorea constantemente que la extremidad no cambie a un color morado.", timer: false },
        { heading: "Uso de Torniquete si es necesario", body: "Si el sangrado es en extremidades y no cesa, coloca un torniquete comercial 5-7 cm por encima de la herida.", tip: "Nunca lo apliques sobre articulaciones como codos o rodillas.", timer: false },
        { heading: "Anotar la hora del torniquete", body: "Escribe la hora exacta en la que se ajustó el dispositivo para informar al cuerpo paramédico.", tip: "No aflojes el torniquete una vez puesto.", timer: false }
      ]
    },
    {
      id: "fracturas",
      title: "Fracturas y Esguinces",
      icon: "🤕",
      category: "Traumas",
      badge: "",
      badgeClass: "",
      colorClass: "amber",
      subTitle: "Inmovilizar zona afectada",
      steps: [
        { heading: "No mover la extremidad", body: "Mantén la zona afectada en la posición exacta en la que la encontraste. No intentes reajustar o enderezar el hueso.", tip: "Moverlo puede causar daños internos en vasos sanguíneos.", timer: false },
        { heading: "Inmovilizar con tablillas", body: "Coloca un soporte rígido (madera, cartón grueso o revistas) a los lados de la lesión asegurándolo con vendas o pañuelos.", tip: "Asegúrate de que la inmovilización cubra las articulaciones de arriba y abajo.", timer: false },
        { heading: "Aplicar frío local", body: "Coloca compresas frías o una bolsa de hielo envuelta en un paño sobre el área para mitigar la inflamación y el dolor.", tip: "Nunca apliques hielo directo sobre la piel desnuda.", timer: false },
        { heading: "Controlar la circulación", body: "Verifica periódicamente que los dedos de la extremidad inmovilizada mantengan temperatura y sensibilidad.", tip: "Si se tornan fríos o pálidos, afloja un poco el vendaje.", timer: false },
        { heading: "Evitar la ingesta de alimentos", body: "No suministres comida ni líquidos al paciente en caso de que requiera cirugía de urgencia.", tip: "Mantén al paciente cómodo y abrigado.", timer: false },
        { heading: "Esperar asistencia profesional", body: "Monitorea el estado general de la persona hasta el arribo de la ambulancia.", tip: "Tranquiliza al paciente constantemente.", timer: false }
      ]
    },
    {
      id: "ahogamiento",
      title: "Ahogamiento",
      icon: "🌊",
      category: "Respiración",
      badge: "",
      badgeClass: "",
      colorClass: "blue",
      subTitle: "Rescate acuático inicial",
      steps: [
        { heading: "Retirar del agua con seguridad", body: "Saca a la persona del agua garantizando primero tu propia seguridad en el entorno.", tip: "Usa objetos de rescate flotantes si es posible.", timer: false },
        { heading: "Evaluar consciencia y respiración", body: "Recuesta a la víctima boca arriba sobre una superficie firme y comprueba si responde o respira.", tip: "No intentes extraer agua de los pulmones mediante golpes.", timer: false },
        { heading: "Iniciar ventilaciones de rescate", body: "Si no respira, proporciona 5 ventilaciones iniciales boca a boca abriendo la vía aérea.", tip: "En ahogamiento, el oxígeno inicial es crucial.", timer: false },
        { heading: "Alternar compresiones torácicas", body: "Continúa con ciclos regulares de 30 compresiones seguidas de 2 ventilaciones de forma continua.", tip: "Mantén el ritmo constante ayudándote del temporizador.", timer: true },
        { heading: "Colocar en posición lateral", body: "Si la persona recupera la consciencia y respira, colócala en Posición Lateral de Seguridad (PLS) para evitar broncoaspiración por vómito.", tip: "Retira la ropa húmeda y arrópala.", timer: false }
      ]
    },
    {
      id: "quemaduras",
      title: "Quemaduras",
      icon: "🔥",
      category: "Quemaduras",
      badge: "",
      badgeClass: "",
      colorClass: "amber",
      subTitle: "Tratamiento térmico inicial",
      steps: [
        { heading: "Enfriar la zona afectada", body: "Coloca la quemadura bajo el chorro de agua fría o templada durante al menos 10 a 15 minutos consecutivos. No utilices hielo directo.", tip: "El agua fría detiene la progresión del daño térmico celular.", timer: false },
        { heading: "Retirar prendas u objetos", body: "Quita con cuidado anillos, pulseras o ropa suelta de la zona antes de que comience a inflamarse.", tip: "No arranques la ropa si está adherida a la quemadura.", timer: false },
        { heading: "Proteger la quemadura", body: "Cubre suavemente la superficie dañada con una gasa estéril o un paño completamente limpio y seco sin presionar.", tip: "Bajo ninguna circunstancia apliques remedios caseros como pasta dental.", timer: false },
        { heading: "No reventar ampollas", body: "Mantén intactas las ampollas que se hayan formado, ya que actúan como barrera natural contra infecciones.", tip: "Si se rompen solas, lava con agua limpia y jabón suave.", timer: false }
      ]
    },
    {
      id: "convulsiones",
      title: "Convulsiones",
      icon: "⚡",
      category: "Críticas",
      badge: "",
      badgeClass: "",
      colorClass: "blue",
      subTitle: "Protección y control de crisis",
      steps: [
        { heading: "Despejar el entorno", body: "Retira objetos filosos, duros o calientes cercanos al paciente para evitar que se lastime durante los espasmos.", tip: "No intentes sujetarlo o detener sus movimientos por la fuerza.", timer: false },
        { heading: "Proteger la cabeza", body: "Coloca algo suave como una almohadilla, chaqueta o prenda doblada debajo de su cabeza.", tip: "Evita que impacte repetidamente contra el suelo.", timer: false },
        { heading: "No introducir objetos en la boca", body: "Nunca metas los dedos, pañuelos ni objetos rígidos en la boca del paciente.", tip: "Es un mito que puedan tragarse la lengua, puedes causarle fracturas dentales.", timer: false },
        { heading: "Controlar el tiempo de la crisis", body: "Toma nota mental de la duración exacta de la convulsión.", tip: "Si la crisis dura más de 5 minutos, llama inmediatamente al 911.", timer: false },
        { heading: "Posición de recuperación al finalizar", body: "Una vez que cesen los movimientos, gíralo con cuidado hacia un lado (posición de seguridad) para mantener su vía respiratoria libre.", tip: "Permanece a su lado hasta que recupere la orientación por completo.", timer: false }
      ]
    },
    {
      id: "desmayo",
      title: "Desmayo",
      icon: "😵‍💫",
      category: "Críticas",
      badge: "",
      badgeClass: "",
      colorClass: "blue",
      subTitle: "Recuperación de consciencia",
      steps: [
        { heading: "Elevar las piernas", body: "Acuesta al paciente boca arriba y eleva sus piernas unos 30 centímetros sobre el nivel del corazón para mejorar el flujo sanguíneo cerebral.", tip: "Afloja prendas ajustadas como corbatas, collares o cinturones.", timer: false },
        { heading: "Garantizar ventilación adecuada", body: "Asegúrate de que el espacio esté bien ventilado y pide a las personas alrededor que no se aglomeren.", tip: "No le arrojes agua a la cara ni le des alcohol para oler.", timer: false },
        { heading: "Evaluar tiempo de recuperación", body: "Espera a que el paciente recupere el sentido de forma progresiva. Por lo general toma menos de un minuto.", tip: "Si permanece inconsciente más tiempo, trátalo como emergencia crítica.", timer: false }
      ]
    }
  ];

  let currentProtocol = null;
  let currentStepIndex = 0;
  const screens = ['welcome', 'home', 'guide', 'map', 'learn', 'profile'];
  const navMap = { home: 'nav-home', map: 'nav-map', learn: 'nav-learn', profile: 'nav-profile' };

  // ── 2. CARGA INICIAL Y RELOJ ──
  document.addEventListener("DOMContentLoaded", () => {
    const updateClock = () => {
        const el = document.getElementById("device-time");
        if (el) {
            const now = new Date();
            el.textContent = String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0');
        }
    };
    setInterval(updateClock, 1000);
    updateClock();

    // Consulta al backend para ver si hay datos
    fetch('https://plum-goose-105133.hostinger.com/get_perfil.php')
        .then(res => res.json())
        .then(data => {
            if (data && data.nombre_completo) {
                showScreen('home');
                aplicarDatosAPerfil(data);
            } else {
                showScreen('welcome');
            }
        })
        .catch(() => showScreen('welcome'));

    renderCards(DB_PROTOCOLS);
    
    const sosBtn = document.getElementById("sos-btn-trigger");
    if (sosBtn) {
        sosBtn.addEventListener("click", () => {
            alert("🚨 SOS ACTIVADO: Llamando al 911.");
            window.location.href = "tel:911";
        });
    }
  });

  // ── 3. FUNCIONES DEL PERFIL Y FORMULARIO ──
  function aplicarDatosAPerfil(data) {
      if (!data || !data.nombre_completo) return;
      document.getElementById("prof-display-name").textContent = data.nombre_completo;
      document.getElementById("prof-display-blood").textContent = "🩸 Tipo " + data.tipo_sangre;
      
      const condEl = document.getElementById("prof-display-conditions");
      const allEl = document.getElementById("prof-display-allergies");
      
      if (condEl) condEl.innerHTML = `<span class="med-tag">${data.condiciones_medicas || 'Ninguna'}</span>`;
      if (allEl) allEl.innerHTML = `<span class="med-tag">${data.alergias || 'Ninguna'}</span>`;

      const list = document.getElementById("prof-display-contacts-list");
      if (list && data.contacts) {
          list.innerHTML = "";
          data.contacts.forEach(c => {
              const numeroLimpio = c.telefono.replace(/\s+/g, '');
              list.innerHTML += `
                  <div class="contact-card">
                      <div class="contact-avatar">👤</div>
                      <div>
                        <div class="contact-name">${c.nombre}</div>
                        <div class="contact-rel">${c.telefono}</div>
                      </div>
                      <button class="contact-call" onclick="window.location.href='tel:${numeroLimpio}'">📞</button>
                  </div>`;
          });
      }
  }

  function reiniciarApp() {
      if(confirm("¿Estás seguro de borrar todos tus datos de salud y contactos?")) {
          localStorage.clear();
          window.location.href = "index.php?reset=true"; 
      }
  }

  function addContactToForm() {
      const nameVal = document.getElementById("temp-cname").value;
      const phoneVal = document.getElementById("temp-cphone").value;
      
      if (!nameVal || !phoneVal) { alert("Llena nombre y teléfono"); return; }
      
      const container = document.getElementById("contacts-inputs-container");
      container.innerHTML += `
          <div class="added-contact-pill">
              ${nameVal}: ${phoneVal}
              <input type="hidden" name="contactos_nombre[]" value="${nameVal}">
              <input type="hidden" name="contactos_telefono[]" value="${phoneVal}">
          </div>
      `;
      
      document.getElementById("temp-cname").value = "";
      document.getElementById("temp-cphone").value = "";
  }

  function saveInitialRegistration() {
      const name = document.getElementById("reg-name").value.trim();
      if (!name) {
          alert("⚠️ Por favor, introduce tu nombre.");
          return false;
      }
      return true;
  }

  // ── 4. FUNCIONES DE UI Y PROTOCOLOS ──
  function showScreen(name) {
      screens.forEach(s => {
          const el = document.getElementById('screen-' + s);
          if (el) el.classList.toggle('active', s === name);
      });
      Object.entries(navMap).forEach(([screen, id]) => {
          const el = document.getElementById(id);
          if (el) el.classList.toggle('active', screen === name);
      });
      const bottomNav = document.getElementById('main-bottom-nav');
      if (bottomNav) {
          bottomNav.style.display = (name === 'welcome' || name === 'guide') ? "none" : "flex";
      }
  }

  function renderCards(protocolsList) {
      const grid = document.getElementById("emergencies-grid");
      if (!grid) return;
      grid.innerHTML = "";
      protocolsList.forEach(p => {
          const card = document.createElement("div");
          card.className = `card ${p.colorClass}`;
          card.onclick = () => launchProtocol(p.id);
          card.innerHTML = `
              <span class="card-icon">${p.icon}</span>
              <div class="card-title">${p.title}</div>
              <div class="card-steps">${p.steps.length} pasos</div>
          `;
          grid.appendChild(card);
      });
  }

  function filterCategory(cat, el) {
      document.querySelectorAll(".pill").forEach(p => { p.className = "pill inactive"; });
      el.className = "pill active";
      if (cat === "Todas") {
          renderCards(DB_PROTOCOLS);
      } else {
          const filtered = DB_PROTOCOLS.filter(p => p.category === cat);
          renderCards(filtered);
      }
  }

  function filterEmergencies() {
      const query = document.getElementById("search-input").value.toLowerCase();
      const filtered = DB_PROTOCOLS.filter(p => p.title.toLowerCase().includes(query));
      renderCards(filtered);
  }

  function launchProtocol(id) {
      currentProtocol = DB_PROTOCOLS.find(p => p.id === id);
      if (!currentProtocol) return;
      currentStepIndex = 0;
      document.getElementById("guide-main-title").textContent = currentProtocol.title;
      document.getElementById("guide-sub-title").textContent = currentProtocol.subTitle;
      
      const dotsContainer = document.getElementById("step-dots-container");
      if (dotsContainer) {
          dotsContainer.innerHTML = "";
          currentProtocol.steps.forEach(() => {
              const dot = document.createElement("div");
              dot.className = "step-dot";
              dotsContainer.appendChild(dot);
          });
      }
      renderCurrentStep();
      showScreen('guide');
  }

  function renderCurrentStep() {
      if (!currentProtocol) return;
      const step = currentProtocol.steps[currentStepIndex];
      document.getElementById("step-counter-text").textContent = `Paso ${currentStepIndex + 1} de ${currentProtocol.steps.length}`;
      document.getElementById("step-card-number").textContent = `Paso ${currentStepIndex + 1}`;
      document.getElementById("step-card-heading").textContent = step.heading;
      document.getElementById("step-card-body").textContent = step.body;
      document.getElementById("step-card-tip").textContent = `💡 ${step.tip}`;

      const dots = document.querySelectorAll("#step-dots-container .step-dot");
      dots.forEach((dot, idx) => {
          dot.className = "step-dot";
          if (idx < currentStepIndex) dot.classList.add("done");
          if (idx === currentStepIndex) dot.classList.add("active");
      });
  }

  function nextStep() {
      if (currentStepIndex < currentProtocol.steps.length - 1) {
          currentStepIndex++;
          renderCurrentStep();
      } else {
          showScreen('home');
      }
  }

  // ── 5. SERVICE WORKER ──
  if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
          navigator.serviceWorker.register('sw.js')
              .then((reg) => console.log('VITALIS PWA: Service Worker registrado.', reg.scope))
              .catch((err) => console.error('VITALIS PWA: Error Service Worker: ', err));
      });
  }
</script>

<?php if (isset($mensaje_debug) && $mensaje_debug !== ""): ?>
    <script>alert("<?php echo addslashes($mensaje_debug); ?>");</script>
<?php endif; ?>

</body>
</html>