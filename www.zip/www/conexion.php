<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$host = "mysql.tudominio.com"; // Hostinger te dará esta dirección
$dbname = "u123456789_vitalis";
$username = "u123456789_usuario";
$password = "TuContrasenaSegura";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
} catch (PDOException $e) {
    die(json_encode(["error" => "Error de conexión"]));
}
?>